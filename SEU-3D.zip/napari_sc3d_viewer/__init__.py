__version__ = "1.1.0"

from ._widget_load import LoadAtlas
from ._widget_register import RegisterSc3D
